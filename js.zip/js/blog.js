  // deault swiper
  var swiper = new Swiper(".swiper-basic", {
    loop: true,
    autoplay: {
        delay: 1500,
        disableOnInteraction: false,
    }
});